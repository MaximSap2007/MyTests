i = 234
if i >= 230 :
  print("i is smaller than 230")

else:
   print("i is bigger than 230")

