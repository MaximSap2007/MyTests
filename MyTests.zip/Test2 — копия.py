i = 0
for i in range(100000*10):
  print(i+1*24)